#ifndef _BITS_STRUCT_STAT_TIME64_H
#define _BITS_STRUCT_STAT_TIME64_H 1

#define __stat64_t64 stat64

#endif
